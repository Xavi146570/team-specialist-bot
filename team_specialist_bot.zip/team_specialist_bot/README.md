# Team Specialist Bot - FC Porto, Benfica, Sporting

Bot especializado em análise dos 3 Grandes de Portugal com **valores MÍNIMOS** (não médias).

## 🎯 Características

- ✅ Análise histórica de 5 anos (2019-2024)
- ✅ Cálculo de valores mínimos a 70%, 80%, 90% de confiança
- ✅ Kelly Criterion para dimensionamento de stake
- ✅ 12 triggers (6 pré-jogo + 6 live HT)
- ✅ Monitorização live HT após 30 minutos
- ✅ Relatórios PDF consolidados
- ✅ Alertas Telegram
- ✅ ~3 jogos/semana

## 📊 Metodologia

### Valores Mínimos vs Médias

**Exemplo FC Porto em casa:**
- ❌ Média: 3.2 golos/jogo (enganador)
- ✅ Mínimo 90%: 2 golos (aposta segura)
- ✅ Mínimo 80%: 3 golos (confiança alta)
- ✅ Mínimo 70%: 4 golos (agressivo)

### Kelly Criterion

```
f = (bp - q) / b

f = fração do bankroll
b = odds - 1
p = probabilidade (dos dados históricos mínimos)
q = 1 - p
```

## 🔧 Instalação

### 1. Clone do GitHub

```bash
git clone https://github.com/seu-usuario/team-specialist-bot.git
cd team-specialist-bot
```

### 2. Configurar variáveis de ambiente

```bash
cp .env.example .env
```

Editar `.env` com:
- API-Football key
- Supabase URL + Service Key
- Telegram Bot Token + Chat ID

### 3. Deploy no Railway

1. Criar novo projeto no Railway
2. Conectar repositório GitHub
3. Adicionar variáveis de ambiente
4. Deploy automático

## 📁 Estrutura

```
team_specialist_bot/
├── main.py                          # Entry point
├── modules/
│   ├── data_collector.py           # API-Football integration
│   ├── minimum_analyzer.py         # Cálculo de mínimos 70%/80%/90%
│   ├── trigger_detector.py         # Deteção dos 12 triggers
│   ├── kelly_calculator.py         # Kelly Criterion
│   ├── live_monitor.py             # Monitorização HT 30-45min
│   ├── pdf_generator.py            # Relatórios PDF
│   ├── telegram_notifier.py        # Alertas Telegram
│   └── supabase_client.py          # Database integration
├── requirements.txt
├── Dockerfile
└── README.md
```

## 🎲 Triggers Implementados

### Pré-Jogo (6)
1. `vs_bottom5_home` - Casa vs equipas 16º-18º
2. `vs_top3_home` - Casa vs outros Big 3
3. `post_loss_home` - Casa após derrota
4. `classico` - Porto vs Benfica/Sporting
5. `champions_week` - Semana com Champions
6. `vs_bottom5_away` - Fora vs equipas fracas

### Live HT (6)
7. `ht_0x0_after_30min_home` - 0-0 aos 30-45min em casa
8. `ht_1x0_winning_home` - 1-0 ao intervalo em casa
9. `ht_losing_home` - A perder ao intervalo em casa
10. `ht_drawing_away` - Empate ao intervalo fora
11. `ht_0x0_after_30min_away` - 0-0 aos 30-45min fora
12. `second_half_momentum` - Força na 2ª parte

## ⏰ Agendamento

- **Análise completa**: Domingos às 02:00 (semanal)
- **Check próximos jogos**: Diariamente às 10:00 e 18:00
- **Monitorização live**: A cada 5 minutos

## 📈 Output

### 1. Database (Supabase)
- `team_specialist_analysis` - Análises históricas
- `team_trading_plans` - Planos de trading por jogo

### 2. Telegram
- Alertas pré-jogo com plano Kelly
- Alertas live HT com triggers ativos
- Relatório PDF semanal

### 3. PDF Report
- Análise consolidada das 3 equipas
- Tabelas de valores mínimos
- Triggers ativos
- Histórico 5 anos

## 🔐 Segurança

- Service key do Supabase (não usar anon key)
- RLS policies limitam acesso a users premium
- Variáveis de ambiente no Railway (não commit no Git)

## 📝 Logs

```bash
# Railway logs
railway logs

# Local testing
python main.py
```

## 🚀 Próximos Passos

1. ✅ Deploy no Railway
2. ⏳ Gerar análise inicial (5 anos × 3 equipas)
3. ⏳ Criar página frontend `/team-specialist`
4. ⏳ Integração com odds ao vivo
5. ⏳ Champions League calendar integration

## 💡 Notas

- Bot corre 24/7 no Railway
- Análise semanal automática aos domingos
- Alertas apenas para triggers com confiança alta
- Kelly limitado a 25% do bankroll (risk management)

---

**Desenvolvido para análise profissional dos 3 Grandes de Portugal** 🇵🇹
